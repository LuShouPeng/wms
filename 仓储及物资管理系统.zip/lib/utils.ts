export function cn(...classes: (string | undefined | null | boolean)[]) {
  return classes.filter(Boolean).join(' ')
}

export const getStatusBadge = (status: string) => {
  const statusMap = {
    active: { label: '正常', variant: 'success' as const },
    inactive: { label: '停用', variant: 'secondary' as const },
    draft: { label: '草稿', variant: 'warning' as const },
    pending: { label: '待审核', variant: 'warning' as const },
    maintenance: { label: '维护中', variant: 'warning' as const },
    discontinued: { label: '停产', variant: 'destructive' as const },
    completed: { label: '已完成', variant: 'success' as const },
    processing: { label: '处理中', variant: 'info' as const },
    approved: { label: '已审核', variant: 'info' as const },
    rejected: { label: '已拒绝', variant: 'destructive' as const },
    cancelled: { label: '已取消', variant: 'secondary' as const },
    shipped: { label: '已发货', variant: 'info' as const },
    low: { label: '库存不足', variant: 'destructive' as const },
    normal: { label: '正常', variant: 'success' as const },
    high: { label: '库存充足', variant: 'info' as const }
  };
  return statusMap[status] || { label: status, variant: 'default' as const };
};

export const getAlertLevelBadge = (level: string) => {
  const levelMap = {
    high: { label: '高风险', variant: 'destructive' as const },
    medium: { label: '中风险', variant: 'warning' as const },
    low: { label: '低风险', variant: 'success' as const }
  };
  return levelMap[level] || { label: level, variant: 'default' as const };
};